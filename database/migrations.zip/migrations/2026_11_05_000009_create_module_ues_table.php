<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('module_ues', function (Blueprint $table) {
            $table->id('idUe');
            $table->string('libelle_ue');
            $table->integer('nbre_credit');
            $table->string('type_ue');
            $table->foreignId('id_sem')->constrained('semestres', 'id_sem')->cascadeOnDelete();
           $table->unsignedBigInteger('idFiliere')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('module_ues');
    }
};
